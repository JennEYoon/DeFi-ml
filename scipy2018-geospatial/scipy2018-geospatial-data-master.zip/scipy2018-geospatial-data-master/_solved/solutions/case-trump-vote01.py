pres = gpd.read_file("zip://./data/uspres.zip")
pres.head(3)
