pres.crs = {'init':'epsg:4269'}
pres = pres.to_crs(epsg=5070)