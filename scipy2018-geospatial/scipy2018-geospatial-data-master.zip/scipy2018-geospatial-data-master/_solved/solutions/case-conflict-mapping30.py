idx = dist.idxmin()
closest_area = protected_areas_utm.loc[idx, 'NAME_AP']
closest_area