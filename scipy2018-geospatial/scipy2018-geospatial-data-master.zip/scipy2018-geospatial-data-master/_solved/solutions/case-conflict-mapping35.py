data_within_protected['NAME_AP'].value_counts()
# or data_within_protected.groupby('NAME_AP').size()