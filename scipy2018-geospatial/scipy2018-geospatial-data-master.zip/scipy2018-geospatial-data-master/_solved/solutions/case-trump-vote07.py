import libpysal.api as lp
w = lp.Rook.from_dataframe(pres)