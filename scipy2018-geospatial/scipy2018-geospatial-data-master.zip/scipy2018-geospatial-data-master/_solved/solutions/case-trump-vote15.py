#% load _solved/solutions/case-trump-vote14.py
sns.regplot(pres.gini_2015,
            pres.swing_full)