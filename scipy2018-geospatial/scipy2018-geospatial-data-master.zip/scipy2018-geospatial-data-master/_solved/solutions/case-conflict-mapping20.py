ax = protected_areas_utm.plot()
data_utm.plot(ax=ax, color='C1')